

import express from 'express';
import * as autentication from '../controllers/authentication.js'; // Importa todas as funções exportadas no arquivo
import authMiddleware from '../middleware/authorization.js'; // Importa o middleware

const router = express.Router();

// Rotas definidas
router.post('/login', autentication.login); // login
router.post('/cadastro', autentication.cadastro); // cadastro
router.get('/usuario/setor', authMiddleware, autentication.buscarSetor); // buscar setor
router.get('/usuario/nome', authMiddleware, autentication.buscarNome); // buscar nome para saudação
router.post('/request-reset-senha', autentication.requestResetSenha); // solicitar redefinição de senha
router.post('/reset-senha', autentication.resetSenha); // redefinir senha
router.post('/logout', authMiddleware, autentication.logout); // logout

export default router; // Exporta o roteador como padrão
